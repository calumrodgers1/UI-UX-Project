# Interaction Design: Course Website
 This is our course site!

 -Home
 -Menu
 -logo
 intro

 This website contains my feedback towards the program and the reason I chose this program
 
 I made this website with the help from my teacher and some help from internet too

-Design guide
Fonts:https://fonts.googleapis.com/css?family=Roboto+Slab|Source+Sans+Pro&display=swap');



-color

The color I have used is:


color:#aaa;
color:R:0 G:0 B:0;
color:white;
color:R:211 G:211 B:211
color:R:9 G:83 B:145


-footer
The information about my social profile.
 